// Mini InVideo Clone - React App

import React, { useState } from "react";

const scenesFromText = (text) => {
  return text.split(/[.!?]/).filter(Boolean).map((line, i) => ({
    id: i + 1,
    text: line.trim(),
    image: `https://source.unsplash.com/800x450/?nature,${i}`,
    voice: `Voiceover for scene ${i + 1}`
  }));
};

export default function App() {
  const [script, setScript] = useState("");
  const [scenes, setScenes] = useState([]);

  const handleGenerate = () => {
    const generatedScenes = scenesFromText(script);
    setScenes(generatedScenes);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Mini InVideo Clone 🎬</h1>

      <textarea
        rows={6}
        className="w-full p-3 border rounded mb-4"
        placeholder="Type or paste your video script here..."
        value={script}
        onChange={(e) => setScript(e.target.value)}
      />

      <button
        className="bg-blue-600 text-white px-4 py-2 rounded"
        onClick={handleGenerate}
      >
        Generate Scenes
      </button>

      <div className="mt-8 space-y-6">
        {scenes.map((scene) => (
          <div key={scene.id} className="border p-4 rounded shadow">
            <img
              src={scene.image}
              alt={`Scene ${scene.id}`}
              className="w-full h-48 object-cover rounded mb-2"
            />
            <p className="font-semibold mb-1">Scene {scene.id}</p>
            <p className="mb-2">{scene.text}</p>
            <p className="text-sm text-gray-500">🔊 {scene.voice}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
